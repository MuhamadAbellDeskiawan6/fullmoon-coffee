<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8" />
    <title>Pesan Kopi - Fullmoon</title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <script src="https://cdn.tailwindcss.com"></script>
</head>

<body class="bg-[#F8F8F8] text-gray-800">

    <!-- Navbar -->
    <header class="bg-gradient-to-b from-[#BDB5A4] to-[#a79c8d] shadow sticky top-0 z-50">
        <div class="container mx-auto px-4 py-4 flex justify-between items-center">
            <div class="flex items-center space-x-2">
                <img src="/images/fullmoon.png" class="h-10" alt="Fullmoon Logo" />
                <span class="font-bold text-white text-xl">Fullmoon Coffee</span>
            </div>
            <a href="/" class="bg-white text-[#BDB5A4] px-4 py-2 rounded shadow font-semibold hover:bg-gray-100 transition">Beranda</a>
        </div>
    </header>

    <!-- Form Section -->
    <section class="container mx-auto px-4 py-16">
        <div class="max-w-lg mx-auto bg-white p-8 rounded-lg shadow-lg">
            <h1 class="text-3xl font-bold text-center mb-8 text-[#BDB5A4]">Form Pemesanan Kopi Gratis</h1>

            <?php if(session('error')): ?>
            <div class="bg-red-100 text-red-700 p-4 rounded mb-6 text-center"><?php echo e(session('error')); ?></div>
            <?php endif; ?>

            <form action="/order" method="POST" enctype="multipart/form-data" class="space-y-5">
                <?php echo csrf_field(); ?>
                <div>
                    <label class="block text-sm font-semibold mb-1">Nama Lengkap</label>
                    <input type="text" name="nama_pemesan" required class="w-full border px-3 py-2 rounded focus:ring-2 focus:ring-[#BDB5A4]">
                </div>
                <div>
                    <label class="block text-sm font-semibold mb-1">Pilih Menu Kopi</label>
                    <select name="menu_id" required class="w-full border px-3 py-2 rounded focus:ring-2 focus:ring-[#BDB5A4]">
                        <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($menu->id); ?>"><?php echo e($menu->nama); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div>
                    <label class="block text-sm font-semibold mb-1">Username Instagram</label>
                    <input type="text" name="username_ig" required class="w-full border px-3 py-2 rounded focus:ring-2 focus:ring-[#BDB5A4]">
                </div>
                <div>
                    <label class="block text-sm font-semibold mb-1">Nomor WhatsApp</label>
                    <input type="text" name="no_whatsapp" required class="w-full border px-3 py-2 rounded focus:ring-2 focus:ring-[#BDB5A4]">
                </div>
                <button type="submit" class="bg-[#BDB5A4] text-white px-6 py-3 rounded w-full font-semibold hover:bg-[#a79c8d] transition">Kirim Pesanan</button>
            </form>

        </div>
    </section>

    <!-- Footer -->
    <footer class="bg-[#BDB5A4] text-white py-6 mt-12">
        <div class="text-center text-sm">
            &copy; 2025 Fullmoon Coffee | IG: @fullmoon
        </div>
    </footer>

</body>

</html><?php /**PATH C:\Users\User\fullmoon-coffee\resources\views/order.blade.php ENDPATH**/ ?>