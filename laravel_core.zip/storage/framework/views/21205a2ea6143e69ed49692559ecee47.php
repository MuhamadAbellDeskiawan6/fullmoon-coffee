<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <title>Dashboard Admin - Fullmoon</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script src="https://cdn.tailwindcss.com"></script>
</head>

<body class="bg-[#F8F8F8] text-gray-800">
    <?php echo $__env->make('admin.layouts.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <div class="container mx-auto px-4 py-8">
        <h1 class="text-2xl font-bold mb-6">Dashboard Pesanan</h1>

        <?php if(session('success')): ?>
        <div class="bg-green-100 text-green-700 p-4 rounded mb-4"><?php echo e(session('success')); ?></div>
        <?php endif; ?>

        <table class="min-w-full bg-white rounded shadow">
            <thead>
                <tr class="bg-[#BDB5A4] text-white">
                    <th class="py-2 px-4 text-left">Nama</th>
                    <th class="py-2 px-4 text-left">Menu</th>
                    <th class="py-2 px-4 text-left">Username IG</th>
                    <th class="py-2 px-4 text-left">Link Story</th>
                    <th class="py-2 px-4 text-left">No WA</th>
                    <th class="py-2 px-4 text-left">Kontak</th>
                    <th class="py-2 px-4 text-left">Status</th>
                    <th class="py-2 px-4 text-left">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="border-b">
                    <td class="py-2 px-4"><?php echo e($order->nama_pemesan); ?></td>
                    <td class="py-2 px-4"><?php echo e($order->menu->nama); ?></td>
                    <td class="py-2 px-4"><?php echo e($order->username_ig); ?></td>
                    <td class="py-2 px-4">
                        <?php if($order->link_story): ?>
                        <a href="<?php echo e($order->link_story); ?>" target="_blank" class="text-blue-500">Link</a>
                        <?php else: ?>
                        -
                        <?php endif; ?>
                    </td>
                    <td class="py-2 px-4"><?php echo e($order->no_whatsapp); ?></td>
                    <td class="py-2 px-4">
                        <a href="https://wa.me/<?php echo e($order->no_whatsapp); ?>?text=Halo%20<?php echo e(urlencode($order->nama_pemesan)); ?>,%20terima%20kasih%20atas%20pemesanan%20kopi%20Fullmoon%20anda." target="_blank" class="bg-green-500 text-white px-3 py-1 rounded">Chat WA</a>
                    </td>
                    <td class="py-2 px-4">
                        <?php
                        $statusColors = [
                        'pending' => 'text-yellow-600',
                        'approved' => 'text-blue-600',
                        'done' => 'text-green-600',
                        'rejected' => 'text-red-600',
                        ];
                        ?>
                        <span class="<?php echo e($statusColors[$order->status] ?? 'text-gray-800'); ?>">
                            <?php echo e(ucfirst($order->status)); ?>

                        </span>
                    </td>

                    <td class="py-2 px-4">
                        <form action="/admin/order/<?php echo e($order->id); ?>/status" method="POST" class="inline-block">
                            <?php echo csrf_field(); ?>
                            <select name="status" class="border rounded px-2 py-1">
                                <option value="pending" <?php echo e($order->status == 'pending' ? 'selected' : ''); ?>>Pending</option>
                                <option value="approved" <?php echo e($order->status == 'approved' ? 'selected' : ''); ?>>Approved</option>
                                <option value="done" <?php echo e($order->status == 'done' ? 'selected' : ''); ?>>Done</option>
                                <option value="rejected" <?php echo e($order->status == 'rejected' ? 'selected' : ''); ?>>Rejected</option>
                            </select>

                            <button type="submit" class="ml-2 bg-[#BDB5A4] text-white px-3 py-1 rounded">Update</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <!-- Pagination links -->
        <div class="mt-6">
            <?php echo e($orders->links('pagination::tailwind')); ?>

        </div>

        <div class="mt-8">
            <a href="/admin/menus" class="bg-[#BDB5A4] text-white px-4 py-2 rounded">Kelola Menu</a>
        </div>
    </div>

</body>

</html><?php /**PATH C:\Users\User\fullmoon-coffee\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>