<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
</head>

<body>
    <h1>Pesanan Baru Masuk</h1>
    <p>Nama Pemesan: <?php echo e($order->nama_pemesan); ?></p>
    <p>Menu: <?php echo e($order->menu->nama); ?></p>
    <p>Username IG: <?php echo e($order->username_ig); ?></p>
    <p>Nomor WhatsApp: <?php echo e($order->no_whatsapp); ?></p>
    <p>Link Story: <?php echo e($order->link_story); ?></p>
</body>

</html><?php /**PATH C:\Users\User\fullmoon-coffee\resources\views/emails/order_notification.blade.php ENDPATH**/ ?>